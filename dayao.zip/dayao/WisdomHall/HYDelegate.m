//
//  HYDelegate.m
//  WisdomHall
//
//  Created by XTU-TI on 2017/6/28.
//  Copyright © 2017年 majinxing. All rights reserved.
//

#import "HYDelegate.h"

@implementation HYDelegate
-(instancetype)init{
    self = [super init];
    if (self) {
    }
    return self;
}
@end
