//
//  PersonalCollectionViewCell.h
//  WisdomHall
//
//  Created by XTU-TI on 2017/5/4.
//  Copyright © 2017年 majinxing. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SignPeople.h"

@interface PersonalCollectionViewCell : UICollectionViewCell
-(void)setPersonalInfo:(SignPeople *)sign;
@end
