//
//  GroupPeopleViewController.h
//  WisdomHall
//
//  Created by XTU-TI on 2017/10/9.
//  Copyright © 2017年 majinxing. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GroupModel.h"

@interface GroupPeopleViewController : UIViewController
@property (nonatomic,strong)GroupModel * group;
@end
