//
//  ContactModel.m
//  WisdomHall
//
//  Created by XTU-TI on 2017/5/24.
//  Copyright © 2017年 majinxing. All rights reserved.
//

#import "ContactModel.h"

@implementation ContactModel

@end
