//
//  ContactModel.h
//  WisdomHall
//
//  Created by XTU-TI on 2017/5/24.
//  Copyright © 2017年 majinxing. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ContactModel : NSObject
@property (nonatomic,copy) NSString * textId;
@property (nonatomic,copy) NSString * questionsID;
@property (nonatomic,copy) NSString * qid;
@end
