//
//  CollectionFlowLayout.m
//  WisdomHall
//
//  Created by XTU-TI on 2017/5/3.
//  Copyright © 2017年 majinxing. All rights reserved.
//

#import "CollectionFlowLayout.h"

@implementation CollectionFlowLayout
- (instancetype) init {
    if (self = [super init]) {
        self.scrollDirection = UICollectionViewScrollDirectionVertical;
        
    }
    return self;
}
@end
