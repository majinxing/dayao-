//
//  DefineThePasswordViewController.h
//  WisdomHall
//
//  Created by XTU-TI on 2017/4/26.
//  Copyright © 2017年 majinxing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DefineThePasswordViewController : UIViewController
@property (nonatomic,copy)NSString * phoneNumber;
@end
