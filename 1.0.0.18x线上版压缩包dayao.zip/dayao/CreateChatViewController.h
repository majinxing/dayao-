//
//  CreateChatViewController.h
//  WisdomHall
//
//  Created by XTU-TI on 2017/9/25.
//  Copyright © 2017年 majinxing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CreateChatViewController : UIViewController

@end
