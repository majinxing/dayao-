//
//  ResultsOfVoteViewController.h
//  WisdomHall
//
//  Created by XTU-TI on 2017/6/7.
//  Copyright © 2017年 majinxing. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VoteModel.h"

@interface ResultsOfVoteViewController : UIViewController
@property (nonatomic,strong)VoteModel * voteModel;
@end
