//
//  QrCodeViewController.h
//  WisdomHall
//
//  Created by XTU-TI on 2017/10/31.
//  Copyright © 2017年 majinxing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QrCodeViewController : UIViewController
@property (nonatomic,strong)NSMutableDictionary * dict;
@property (nonatomic,strong) NSMutableArray * mck;
@end
