//
//  CompanyProfileViewController.h
//  WisdomHall
//
//  Created by XTU-TI on 2017/7/29.
//  Copyright © 2017年 majinxing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CompanyProfileViewController : UIViewController

@end
