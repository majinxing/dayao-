//
//  NoticeModel.h
//  WisdomHall
//
//  Created by XTU-TI on 2017/7/27.
//  Copyright © 2017年 majinxing. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NoticeModel : NSObject
@property (nonatomic,copy)NSString * noticeTime;
@property (nonatomic,copy)NSString * noticeContent;
@end
