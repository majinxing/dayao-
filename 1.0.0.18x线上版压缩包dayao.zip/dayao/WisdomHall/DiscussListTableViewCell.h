//
//  DiscussListTableViewCell.h
//  WisdomHall
//
//  Created by XTU-TI on 2017/6/13.
//  Copyright © 2017年 majinxing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DiscussListTableViewCell : UITableViewCell
-(void)setImage:(NSString *)imageStr withLableTitle:(NSString *)title;
@end
