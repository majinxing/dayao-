//
//  NoticeModel.m
//  WisdomHall
//
//  Created by XTU-TI on 2017/7/27.
//  Copyright © 2017年 majinxing. All rights reserved.
//

#import "NoticeModel.h"

@implementation NoticeModel

@end
